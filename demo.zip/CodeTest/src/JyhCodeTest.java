import java.io.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.regex.Pattern;

public class JyhCodeTest {
    public static final String currencyFile = "currency.txt";
    public static final String rateFile = "rate.txt";
    public static final String curReg = "[a-zA-Z]{3}";
    public static final String numReg = "[\\+\\-]?[\\d]+(\\.[\\d]+)?";
    public static final String allReg = "[a-zA-Z]{3}\\s[\\+\\-]?[\\d]+(\\.[\\d]+)?";
    public static final Map<String,BigDecimal> currencyMap = new HashMap();
    public static final Map<String,BigDecimal> rateMap = new HashMap();
    public static volatile boolean flag = true;

    public static void main(String[] args) throws Exception {
        JyhCodeTest p = new JyhCodeTest();

        //获得初始化文件
        p.getInitFile();

        //timer是经过封装的多线程,一分钟后开始执行
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                synchronized ("lock") {
                    System.out.println("定时任务输出开始");
                    for (String eachCur : currencyMap.keySet()) {
                        if(currencyMap.get(eachCur).compareTo(BigDecimal.ZERO) == 0){
                            continue;
                        }
                        System.out.println(eachCur + " " + currencyMap.get(eachCur).toString() + (rateMap.get(eachCur) == null?"":"(USD"+currencyMap.get(eachCur).multiply(rateMap.get(eachCur))+")"));
                    }
                    System.out.println("定时任务输出结束，请继续您的操作");
                }
            }
        },60000,60000);

        while (flag){
            //更新货币种类与金额
            p.updateCurrency();
        }
        timer.cancel();
    }

    /**
     * 获得键盘输入
     * @param tip
     * @return
     */
    private String getInput(String tip) {
        System.out.print(tip+"\r\n");
        Scanner sc = new Scanner(System.in);
        sc.useDelimiter("\n");
        return sc.next();
    }

    /**
     * 读取初始化文件
     * @throws Exception
     */
    public void getInitFile() throws Exception {
        File file = new File(currencyFile);
        if (!file.exists()) {
            file.createNewFile();
            return;
        }
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line = null;
        System.out.println("文件初始化开始...");
        while ((line = br.readLine()) != null) {
            if(!line.trim().isEmpty()){
                System.out.println(line);
                if(line.length()<5 || !Pattern.matches(allReg, line)){
                    System.out.println("初始文件有误，只接收3位字母的货币种类，注意货币与金额以单空格隔开，且前三位只能为英文字母");
                    return;
                }
                String currency = line.substring(0, 3);
                if (!Pattern.matches(curReg, currency)){
                    System.out.println("初始文件有误，只接收3位字母的货币种类");
                    return;
                }
                String amountStr = line.substring(4);
                if (!Pattern.matches(numReg, amountStr) || new BigDecimal(amountStr).compareTo(BigDecimal.ZERO) == -1){
                    System.out.println("初始文件有误，只能为数字且数字只能大于等于0");
                    return;
                }
                currencyMap.put(currency,new BigDecimal(amountStr));
            }
        }
        System.out.println("文件初始化结束...");
        File fileRate = new File(rateFile);
        if (!fileRate.exists()) {
            fileRate.createNewFile();
            return;
        }
        BufferedReader rf = new BufferedReader(new FileReader(fileRate));
        String rateLine = null;
        System.out.println("汇率文件初始化开始...");
        while ((rateLine = rf.readLine()) != null) {
            if(!rateLine.trim().isEmpty()){
                System.out.println(rateLine);
                if(!Pattern.matches(allReg, rateLine)){
                    System.out.println("汇率文件有误");
                    return;
                }
                String currency = rateLine.substring(0, 3);
                if (!Pattern.matches(curReg, currency)){
                    System.out.println("汇率文件有误");
                    return;
                }
                String rateStr = rateLine.substring(4);
                if (!Pattern.matches(numReg, rateStr) || new BigDecimal(rateStr).compareTo(BigDecimal.ZERO) == -1){
                    System.out.println("汇率文件有误，只能为数字且数字只能大于等于0");
                    return;
                }
                rateMap.put(currency,new BigDecimal(rateStr));
            }
        }
        System.out.println("汇率文件初始化结束...");
        rf.close();
    }
    public void updateCurrency() throws Exception {
            String str = getInput("请输入货币种类和金额，以单空格隔开(注意货币种类只接受3位字母，如hkd -10.1)，按enter键确定输入，输入exit确定退出:");
            //判断退出程序
            if ("quit".equals(str) || "exit".equals(str)) {
                flag = false;
                return;
            }
            if(str == null || str.isEmpty() || str.length()<5){
                System.out.println("输入有误，只接收3位字母的货币种类，注意货币与金额以单空格隔开，且前三位只能为英文字母");
                return;
            }
            if(!Pattern.matches(allReg, str)){
                System.out.println("输入有误，只接收3位字母的货币种类，注意货币与金额以单空格隔开，且前三位只能为英文字母");
                return;
            }
            String currency = str.substring(0, 3).toUpperCase();
            String amount = str.substring(4);
            //输入校验，货币种类
            if (!Pattern.matches(curReg, currency)) {
                System.out.println("输入有误，只接收3位字母的货币种类，注意货币与金额以单空格隔开，且前三位只能为英文字母");
                return;
            }
            //输入校验，金额
            if (!Pattern.matches(numReg, amount)) {
                System.out.println("输入有误，金额只接收数字，注意货币与金额以单空格隔开");
                return;
            }

            synchronized ("lock") {
                //看看map里有没有此货币，没有则添加，有则计算
                if (currencyMap.containsKey(currency)) {
                    BigDecimal specficAmount = (BigDecimal) currencyMap.get(currency);
                    BigDecimal resultAmount = specficAmount.add(new BigDecimal(amount));
                    if (resultAmount.compareTo(BigDecimal.ZERO) == -1) {
                        System.out.println("输入有误，扣减金额后，货币余额少于0");
                        return;
                    }
                    currencyMap.put(currency, resultAmount);
                } else {
                    if (new BigDecimal(amount).compareTo(BigDecimal.ZERO) == -1) {
                        System.out.println("输入有误，扣减金额后，货币余额少于0");
                        return;
                    }
                    currencyMap.put(currency, new BigDecimal(amount));
                }

                BufferedWriter bw = new BufferedWriter(new FileWriter(
                        new File(currencyFile), false));
                for (String eachCur : currencyMap.keySet()) {
                    bw.write(eachCur + " " + currencyMap.get(eachCur).toString() + "\r\n");
                }
                System.out.println("更新货币金额成功");
                bw.close();
            }
    }
}